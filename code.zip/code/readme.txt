eng_text.ipynb contains our entire code. it will run the model for 10 epochs and save it.

demo.ipynb uses the saved model to give predictions.